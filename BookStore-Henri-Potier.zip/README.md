# BookStore-Henri-Potier

Simulation d'achat de livres avec promotion
Ce projet a été initié avec [Create React App](https://github.com/facebook/create-react-app), en utilisant Node.js v10.16.0.

# Installation

Cloner le dépôt avec `git clone url`, ensuite exécutez `npm install` dans la racine du répertoire du projet.

Pour lancer l'application en mode développement exécutez `npm start`. l'URL [http://localhost:3000] s'ouvrira dans votre navigateur.

Pour lancer les tests unitaires avec Enzyme exécutez `npm run test`.

Pour lancer l'application en mode production exécutez `npm run build`  ensuite déployer le contenu du répertoire `build` sur un serveur web.